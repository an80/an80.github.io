let bee = document.getElementById("bee");
let start = Date.now();
let timer = setInterval(async function(){
    let timepass= Date.now() - start;
    if (timepass >= 9000) {
        bee.style.transform = "scaleX(-1)";
        clearInterval(timer);
        return;
    }
    draw(timepass);
},20);

function draw(timepass){
    bee.style.left = timepass / 5 + 'px';
}
