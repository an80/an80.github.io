<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Кошер</title>
<link href="Huney_welcome.css" media="screen" rel="stylesheet" type="text/css" />
<link rel="preconnect" href="https://fonts.gstatic.com"/>
<link href="https://fonts.googleapis.com/css2?family=Pacifico&display=swap"/> 
</head>
<body>
    <div id="comb">
<h1 id='t_co'>Мед</h1>
<img src="" alt="" id="checkout">
    </div>
    <div id="grid">
<div class="flex">
            <p id="grid_p">Акациев Мед</p>
            <img src="https://i.imgur.com/Wg1f78S.png" alt="" href="">
            <button class="add">Вземи</button>
        </div>
        <div class="flex">
            <p id="grid_p">Мед</p>
            <img src="https://i.imgur.com/Wg1f78S.png" alt="" href="">
            <button class="add">Вземи</button>
        </div>
        <div class="flex">
            <p id="grid_p">Мед</p>
            <img src="https://i.imgur.com/Wg1f78S.png" alt="" href="">
            <button class="add">Вземи</button>
        </div>
        <div class="flex">
            <p id="grid_p">Контакт</p>
            <p id="grid_p">Можете да се регистрирате или да се обадите на нашият телефонен номер за поръчка или питанка:088124912</p>
        </div>
        </div>
</body>
</html>