if 5>2:
    print('Hello World!')
    #This do be a multiline comment
    """
    RRR
    bbb
    ggg
    """
    x = str(3)    # x will be '3'
    y = int(3)    # y will be 3
    z = float(3)  # z will be 3.0 
    print(type(x))
    #case sensitive
    fruit=['annas','plod','strawberry']
    v,r,k=fruit
    q,h,j='you','are','dumby'
    a="I like {} bcs {} and that's {}"
    a.format("oranges","they're cool","super")