<?php session_start();

?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
    </head>
    <body>
        <h1>Мед</h1>
        <img src="" alt="">
        <div class="flex">
            <p>Акациев Мед</p>
            <img src="" alt="" href="">
        </div>
        <div class="flex">
            <p>Мед</p>
            <img src="" alt="" href="">
        </div>
        <div class="flex">
            <p>Мед</p>
            <img src="" alt="" href="">
        </div>
        <div class="flex">
            <p>Контакт</p>
            <p>Можете да се регистрирате или да се обадите на нашият телефонен номер за поръчка или питанка:088124912</p>
        </div>
        <script src="" async defer></script>
    </body>
</html>